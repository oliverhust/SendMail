#!/usr/bin/python
# -*- coding: utf-8 -*-

from ftplib_run import run


def main():
    run()


if __name__ == '__main__':
    main()
